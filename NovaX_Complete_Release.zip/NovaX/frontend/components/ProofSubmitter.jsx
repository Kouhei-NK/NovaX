
import React, { useState } from 'react';
import { generateProof, sendProofToContract } from '../utils/zkProofUtils';
import { useModelHook } from '../hooks/useModelHook';

const ProofSubmitter = () => {
  const { inputValues, weights, bias, modelName } = useModelHook();
  const [proofStatus, setProofStatus] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    setLoading(true);
    try {
      const proof = await generateProof(inputValues, weights, bias);
      const result = await sendProofToContract(proof);
      setProofStatus(result ? '✅ 検証成功' : '❌ 検証失敗');
    } catch (err) {
      setProofStatus('⚠️ エラー：証明生成または送信失敗');
      console.error(err);
    }
    setLoading(false);
  };

  return (
    <div className="proof-submitter">
      <h2>{modelName} - 証明生成</h2>
      <button onClick={handleSubmit} disabled={loading}>
        {loading ? '処理中...' : 'ZK証明生成＆送信'}
      </button>
      {proofStatus && <p>{proofStatus}</p>}
    </div>
  );
};

export default ProofSubmitter;
