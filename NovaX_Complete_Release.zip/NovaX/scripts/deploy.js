
// scripts/deploy.js

const hre = require("hardhat");

async function main() {
  // 1. Deploy zkVerifier
  const ZKVerifier = await hre.ethers.getContractFactory("zkVerifier");
  const zkVerifier = await ZKVerifier.deploy();
  await zkVerifier.deployed();
  console.log("zkVerifier deployed to:", zkVerifier.address);

  // 2. Deploy dAgentRegistry
  const Registry = await hre.ethers.getContractFactory("dAgentRegistry");
  const registry = await Registry.deploy();
  await registry.deployed();
  console.log("dAgentRegistry deployed to:", registry.address);

  // 3. Deploy NovaXSoulbound
  const SBT = await hre.ethers.getContractFactory("NovaXSoulbound");
  const sbt = await SBT.deploy();
  await sbt.deployed();
  console.log("NovaXSoulbound SBT deployed to:", sbt.address);

  // Optional: Deploy Verifiers for each model (if needed individually)
  // const SympCheckVerifier = await hre.ethers.getContractFactory("SympCheckVerifier");
  // const sympVerifier = await SympCheckVerifier.deploy(zkVerifier.address);
  // await sympVerifier.deployed();
  // console.log("SympCheckVerifier deployed to:", sympVerifier.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
