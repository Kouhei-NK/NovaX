
# NovaX - Trustworthy Decentralized AI via ZKML & SBT

NovaX is a Web3-based AI model marketplace where every inference is provably correct via Zero-Knowledge Machine Learning (ZKML). Users can interact with AI agents (dAgents), backed by smart contracts and verified outputs, while contributions are recorded via Soulbound Tokens (SBTs).

---

## 🧠 Features

- ✅ **ZK-Proven AI**: Each model's output is ZK-verified on-chain
- 🧑‍🎓 **dAgents**: NFT-wrapped models users can trust
- 🔐 **Soulbound Trust System**: Every interaction earns transparent trust badges
- 🧰 **Account Abstraction (AA)**: No wallet friction for users
- 🛠️ **Gasless UX**: Pay with reputation, not just tokens

---

## 📦 Directory Structure

```
NovaX/
├── contracts/
│   ├── zkVerifier.sol
│   ├── dAgentRegistry.sol
│   ├── NovaXSoulbound.sol
│   ├── SympCheckVerifier.sol
│   ├── CreditGuardVerifier.sol
│   └── EduPathVerifier.sol
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── ModelCard.jsx
│   │   │   ├── ProofSubmitter.jsx
│   │   │   └── SBTViewer.jsx
│   │   ├── hooks/
│   │   │   └── useModelHook.js
│   │   └── utils/
│   │       └── zkProofUtils.js
├── zkml-circuits/
│   ├── SympCheckAI.circom
│   ├── CreditGuard.circom
│   ├── EduPathFit.circom
│   └── input.json
├── docs/
│   ├── README.md
│   └── NovaX_ZKML_SnarkJS_Guide.txt
```

---

## 🚀 Quick Start

1. **Install Circom & SnarkJS**
```bash
npm install -g circom snarkjs
```

2. **Compile Circuit**
```bash
circom SympCheckAI.circom --r1cs --wasm -o ./build
```

3. **Generate Keys & Proof**
```bash
snarkjs powersoftau new bn128 12 pot12.ptau -v
snarkjs groth16 setup build/SympCheckAI.r1cs pot12.ptau build/zkey.zkey
snarkjs groth16 prove build/zkey.zkey input.json proof.json public.json
snarkjs groth16 verify verification_key.json public.json proof.json
```

4. **Deploy Contracts**
```bash
npx hardhat run scripts/deploy.js --network mumbai
```

5. **Run dApp Frontend**
```bash
cd frontend
npm install && npm run dev
```

---

## 🔗 Links

- Discord: https://discord.gg/novax  
- Whitepaper: /docs/NovaX_WhitePaper_EN_v1.0.txt  
- Demo: [Coming Soon - Testnet Deployment]

---

NovaX: AI you can prove, trust, and own.
